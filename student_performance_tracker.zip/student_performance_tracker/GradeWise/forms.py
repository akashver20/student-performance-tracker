# yourapp/forms.py

from django import forms
from django.contrib.auth.models import User


# class CreateClassForm(forms.ModelForm):
#     class Meta:
#         model = Class
#         fields = ['department', 'name']

# class UploadStudentsForm(forms.Form):
#     excel_file = forms.FileField()





        